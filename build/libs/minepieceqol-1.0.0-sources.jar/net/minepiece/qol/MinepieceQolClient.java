package net.minepiece.qol;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_7923;
import net.minepiece.qol.commands.ModCommands;
import net.minepiece.qol.config.ConfigManager;
import net.minepiece.qol.mixin.PlayerListHudAccessor;
import net.minepiece.qol.parse.ChatParsers;
import net.minepiece.qol.parse.TooltipParsers;
import net.minepiece.qol.state.AuctionHighlighter;
import net.minepiece.qol.state.BossTracker;
import net.minepiece.qol.state.CooldownTracker;
import net.minepiece.qol.state.DebugLogManager;
import net.minepiece.qol.state.EventCountdownTracker;
import net.minepiece.qol.state.JobsTracker;
import net.minepiece.qol.state.MoneyTracker;
import net.minepiece.qol.state.PersistentState;
import net.minepiece.qol.state.ProfileStatsTracker;
import net.minepiece.qol.state.StatsRefreshController;
import net.minepiece.qol.ui.HudOverlay;
import net.minepiece.qol.ui.HudLayoutScreen;
import net.minepiece.qol.ui.MinibossWaypointWorldRenderer;
import net.minepiece.qol.util.SafeExecutor;
import net.minepiece.qol.util.TextUtil;
import org.lwjgl.glfw.GLFW;

public final class MinepieceQolClient implements ClientModInitializer {
    private static MinepieceQolClient instance;

    private ConfigManager configManager;
    private ConfigManager.ModConfig config;
    private PersistentState persistentState;

    private DebugLogManager debugLogManager;
    private AuctionHighlighter auctionHighlighter;
    private BossTracker bossTracker;
    private CooldownTracker cooldownTracker;
    private ProfileStatsTracker profileStatsTracker;
    private StatsRefreshController statsRefreshController;
    private JobsTracker jobsTracker;
    private MoneyTracker moneyTracker;
    private EventCountdownTracker eventCountdownTracker;
    private HudOverlay hudOverlay;
    private MinibossWaypointWorldRenderer minibossWaypointWorldRenderer;

    private final Map<Integer, String> lastAuctionDebugLines = new HashMap<>();
    private String lastTabFooter = "";
    private boolean hudEditMode;
    private int hudEditSelectedPanel = 1;
    private final Map<Integer, Boolean> hudKeyLatch = new HashMap<>();

    public static MinepieceQolClient get() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;
        System.out.println("MinepieceQOL CLIENT INITIALIZED");

        this.configManager = new ConfigManager();
        this.configManager.ensureDirectories();
        this.config = this.configManager.loadConfig();
        this.persistentState = this.configManager.loadState();

        this.debugLogManager = new DebugLogManager(this.configManager.getBaseDir(), this.config.debugEnabled);
        this.auctionHighlighter = new AuctionHighlighter();
        this.bossTracker = new BossTracker(this.persistentState, this::savePersistentState, this.debugLogManager);
        this.cooldownTracker = new CooldownTracker();
        this.profileStatsTracker = new ProfileStatsTracker();
        this.statsRefreshController = new StatsRefreshController(this.profileStatsTracker, this::sendProfileCommand, this.debugLogManager);
        this.jobsTracker = new JobsTracker(this.persistentState, this::savePersistentState, this.debugLogManager);
        this.moneyTracker = new MoneyTracker(this.persistentState, this::savePersistentState, this.configManager.getBaseDir());
        this.eventCountdownTracker = new EventCountdownTracker(this.persistentState, this::savePersistentState);
        this.hudOverlay = new HudOverlay(this);
        this.minibossWaypointWorldRenderer = new MinibossWaypointWorldRenderer(this);

        ItemTooltipCallback.EVENT.register((stack, context, type, lines) ->
            SafeExecutor.run(this.debugLogManager, "tooltip", () -> this.handleTooltip(stack, lines)));
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> ModCommands.register(dispatcher, this));
        ClientSendMessageEvents.COMMAND.register(command -> {
            this.moneyTracker.onCommandSent(command);
            this.onCommandSent(command);
        });
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> savePersistentState(this.persistentState));
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.SUBTITLES,
            class_2960.method_60655("minepiece-qol", "main_hud"),
            (drawContext, tickCounter) -> this.hudOverlay.render(drawContext)
        );
        this.minibossWaypointWorldRenderer.register();
    }

    public ConfigManager.ModConfig getConfig() {
        return this.config;
    }

    public BossTracker getBossTracker() {
        return this.bossTracker;
    }

    public CooldownTracker getCooldownTracker() {
        return this.cooldownTracker;
    }

    public ProfileStatsTracker getProfileStatsTracker() {
        return this.profileStatsTracker;
    }

    public StatsRefreshController getStatsRefreshController() {
        return this.statsRefreshController;
    }

    public JobsTracker getJobsTracker() {
        return this.jobsTracker;
    }

    public MoneyTracker getMoneyTracker() {
        return this.moneyTracker;
    }

    public EventCountdownTracker getEventCountdownTracker() {
        return this.eventCountdownTracker;
    }

    public boolean isHudEditMode() {
        return this.hudEditMode;
    }

    public int getHudEditSelectedPanel() {
        return this.hudEditSelectedPanel;
    }

    public void setHudEditSelectedPanel(int panelId) {
        this.hudEditSelectedPanel = Math.max(1, Math.min(6, panelId));
    }

    public int getHudPanelCount() {
        return 6;
    }

    public String getHudPanelName(int panelId) {
        return switch (panelId) {
            case 1 -> "Jobs";
            case 2 -> "Money";
            case 3 -> "Stats";
            case 4 -> "Bosses";
            case 5 -> "Event Timer";
            case 6 -> "Haki";
            default -> "Unknown";
        };
    }

    public int getHudPanelX(int panelId) {
        return switch (panelId) {
            case 1 -> this.config.jobsHudX;
            case 2 -> this.config.moneyHudX;
            case 3 -> this.config.statsHudX;
            case 4 -> this.config.bossHudX;
            case 5 -> this.config.eventsHudX;
            case 6 -> this.config.hakiHudX;
            default -> 0;
        };
    }

    public int getHudPanelY(int panelId) {
        return switch (panelId) {
            case 1 -> this.config.jobsHudY;
            case 2 -> this.config.moneyHudY;
            case 3 -> this.config.statsHudY;
            case 4 -> this.config.bossHudY;
            case 5 -> this.config.eventsHudY;
            case 6 -> this.config.hakiHudY;
            default -> 0;
        };
    }

    public float getHudPanelScale(int panelId) {
        return switch (panelId) {
            case 1 -> this.config.jobsHudScale;
            case 2 -> this.config.moneyHudScale;
            case 3 -> this.config.statsHudScale;
            case 4 -> this.config.bossHudScale;
            case 5 -> this.config.eventsHudScale;
            case 6 -> this.config.hakiHudScale;
            default -> 1.0F;
        };
    }

    public void setHudPanelLayout(int panelId, int x, int y, float scale) {
        float clampedScale = Math.max(0.6F, Math.min(1.8F, scale));
        switch (panelId) {
            case 1 -> {
                this.config.jobsHudX = x;
                this.config.jobsHudY = y;
                this.config.jobsHudScale = clampedScale;
            }
            case 2 -> {
                this.config.moneyHudX = x;
                this.config.moneyHudY = y;
                this.config.moneyHudScale = clampedScale;
            }
            case 3 -> {
                this.config.statsHudX = x;
                this.config.statsHudY = y;
                this.config.statsHudScale = clampedScale;
            }
            case 4 -> {
                this.config.bossHudX = x;
                this.config.bossHudY = y;
                this.config.bossHudScale = clampedScale;
            }
            case 5 -> {
                this.config.eventsHudX = x;
                this.config.eventsHudY = y;
                this.config.eventsHudScale = clampedScale;
            }
            case 6 -> {
                this.config.hakiHudX = x;
                this.config.hakiHudY = y;
                this.config.hakiHudScale = clampedScale;
            }
            default -> {
            }
        }
    }

    public void saveConfig() {
        this.configManager.saveConfig(this.config);
    }

    public void onHudLayoutEditorClosed() {
        this.hudEditMode = false;
        this.configManager.saveConfig(this.config);
    }

    public int resolveHakiHudX(class_310 client) {
        if (this.config.hakiHudX >= 0) {
            return this.config.hakiHudX;
        }
        int centerX = client.method_22683().method_4486() / 2;
        int hotbarStartX = centerX - 91;
        return hotbarStartX - 17;
    }

    public int resolveHakiHudY(class_310 client) {
        if (this.config.hakiHudY >= 0) {
            return this.config.hakiHudY;
        }
        return client.method_22683().method_4502() - this.config.cooldownHudOffsetY - 9;
    }

    public DebugLogManager getDebugLogManager() {
        return this.debugLogManager;
    }

    public void handleChatMessage(class_2561 message) {
        String normalized = TextUtil.normalize(message);
        if (normalized.isBlank()) {
            return;
        }

        this.debugLogManager.logChat(normalized);
        SafeExecutor.run(this.debugLogManager, "chat", () -> {
            this.jobsTracker.captureChatMessage(normalized);
            this.cooldownTracker.onChatMessage(normalized);
            this.moneyTracker.onChatMessage(normalized);
            ChatParsers.parseBossKill(normalized).ifPresent(this.bossTracker::onBossKill);
        });
    }

    public void handleActionbarMessage(class_2561 message) {
        String normalized = TextUtil.normalize(message);
        if (normalized.isBlank()) {
            return;
        }

        this.debugLogManager.logActionbar(normalized);
        SafeExecutor.run(this.debugLogManager, "actionbar", () -> {
            this.moneyTracker.onActionbarMessage(normalized);
            this.jobsTracker.captureActionbar(normalized);
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1724 != null) {
                int x = (int) Math.floor(client.field_1724.method_23317());
                int y = (int) Math.floor(client.field_1724.method_23318());
                int z = (int) Math.floor(client.field_1724.method_23321());
                this.bossTracker.captureMinibossActionbar(normalized, x, y, z);
            }
        });
    }

    public void handleTitle(class_2561 message) {
        String normalized = TextUtil.normalize(message);
        if (!normalized.isBlank()) {
            this.debugLogManager.logTitle(normalized);
            SafeExecutor.run(this.debugLogManager, "title", () -> {
                this.jobsTracker.captureVisibleText(normalized);
            });
        }
    }

    public void renderAuctionTint(class_332 drawContext, int slotX, int slotY, int screenX, int screenY, class_1735 slot) {
        if (!this.config.allFeaturesVisible) {
            this.lastAuctionDebugLines.remove(slot.field_7874);
            return;
        }

        Optional<AuctionHighlighter.ActiveHighlight> highlight = getAuctionHighlightForSlot(slot);
        if (highlight.isEmpty()) {
            this.lastAuctionDebugLines.remove(slot.field_7874);
            return;
        }

        AuctionHighlighter.ActiveHighlight activeHighlight = highlight.get();
        drawContext.method_25294(slotX, slotY, slotX + 16, slotY + 16, activeHighlight.argbColor());
        logAuctionHighlight(activeHighlight, slot, screenX, screenY);
    }

    public void clearAuctionTint() {
        this.lastAuctionDebugLines.clear();
    }

    public void captureBossFromHoveredSlot(class_1735 slot) {
        if (slot == null || !slot.method_7681()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) {
            return;
        }

        class_1799 stack = slot.method_7677();
        List<class_2561> tooltip = stack.method_7950(class_1792.class_9635.field_51353, client.field_1724, class_1836.field_41070);
        captureBossFromTooltipLines(stack, tooltip);
    }

    public void captureBossFromTooltipLines(class_1799 stack, List<class_2561> tooltip) {
        if (stack == null || stack.method_7960() || tooltip == null || tooltip.isEmpty()) {
            return;
        }
        List<String> normalizedLines = TextUtil.normalizeLines(tooltip);
        Optional<TooltipParsers.BossTooltipData> parsed = TooltipParsers.parseBossTooltip(normalizedLines, TextUtil.normalize(stack.method_7964()));
        if (parsed.isPresent()) {
            TooltipParsers.BossTooltipData data = parsed.get();
            this.bossTracker.captureParsedTooltip(data);
            this.debugLogManager.logInternal(String.format(
                Locale.ROOT,
                "[BOSS] hover parsed: name=%s coords=(%d,%d,%d) remaining=%ds cycle=%dm lines=%s",
                data.bossName(),
                data.x(),
                data.y(),
                data.z(),
                data.remainingSeconds(),
                Math.max(0, data.cycleSeconds() / 60),
                String.join(" | ", normalizedLines)
            ));
            return;
        }

        if (looksLikeBossTooltip(normalizedLines)) {
            this.debugLogManager.logInternal("[BOSS] hover parse miss: " + String.join(" | ", normalizedLines));
        }
    }

    public void savePersistentState() {
        savePersistentState(this.persistentState);
    }

    public String setJobsOverviewVisible(boolean visible) {
        this.config.jobsOverviewVisible = visible;
        this.configManager.saveConfig(this.config);
        return visible ? "Jobs table shown." : "Jobs table hidden.";
    }

    public String setAllFeaturesVisible(boolean visible) {
        this.config.allFeaturesVisible = visible;
        this.configManager.saveConfig(this.config);
        return visible ? "All mod features shown." : "All mod features hidden.";
    }

    public void sendProfileCommand() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null || client.field_1724.field_3944 == null) {
            return;
        }
        client.field_1724.field_3944.method_45730("profile");
    }

    public void copyLastDebugLine() {
        this.debugLogManager.copyLastToClipboard(class_310.method_1551());
    }

    private void handleTooltip(class_1799 stack, List<class_2561> lines) {
        List<String> normalizedLines = TextUtil.normalizeLines(lines);
        this.debugLogManager.logTooltip(normalizedLines);

        TooltipParsers.parseAuctionHighlight(normalizedLines, stack == null ? 1 : stack.method_7947())
            .ifPresent(result -> this.auctionHighlighter.update(buildAuctionItemKey(stack), result));

        this.tryUpdateStatsFromLines(normalizedLines);
        this.bossTracker.captureTooltip(TextUtil.normalize(stack == null ? null : stack.method_7964()), normalizedLines);

        List<TooltipParsers.PetStatLine> petLines = TooltipParsers.parsePetRolls(
            normalizedLines,
            this.debugLogManager::logInternal
        );
        if (!this.config.allFeaturesVisible) {
            return;
        }
        for (TooltipParsers.PetStatLine petLine : petLines) {
            long rounded = Math.round(petLine.percent());
            class_2561 originalLine = lines.get(petLine.lineIndex());
            lines.set(
                petLine.lineIndex(),
                originalLine.method_27661().method_10852(class_2561.method_43470(String.format(Locale.ROOT, " (%.0f%%)", (double) rounded)))
            );
        }
    }

    private void onClientTick(class_310 client) {
        if (client.field_1724 == null || client.field_1705 == null) {
            return;
        }

        handleHudLayoutEditorHotkey(client);

        SafeExecutor.run(this.debugLogManager, "tab-footer", () -> {
            PlayerListHudAccessor accessor = (PlayerListHudAccessor) client.field_1705.method_1750();
            class_2561 footer = accessor.minepiece$getFooter();
            String normalizedFooter = TextUtil.normalize(footer);
            if (!normalizedFooter.equals(this.lastTabFooter)) {
                this.lastTabFooter = normalizedFooter;
                this.bossTracker.onTablistFooter(normalizedFooter);
                if (!normalizedFooter.isBlank()) {
                    this.debugLogManager.logTabFooter(normalizedFooter);
                }
            }
        });

        this.bossTracker.tick();
        this.eventCountdownTracker.tick();
    }

    private void handleHudLayoutEditorHotkey(class_310 client) {
        if (client == null || client.method_22683() == null) {
            return;
        }

        if (isEdgePressed(client, GLFW.GLFW_KEY_PERIOD)) {
            if (client.field_1755 instanceof HudLayoutScreen) {
                client.method_1507(null);
                return;
            }
            if (client.field_1755 == null) {
                this.hudEditMode = true;
                this.hudEditSelectedPanel = Math.max(1, Math.min(this.hudEditSelectedPanel, getHudPanelCount()));
                if (this.config.hakiHudX < 0 || this.config.hakiHudY < 0) {
                    this.config.hakiHudX = resolveHakiHudX(client);
                    this.config.hakiHudY = resolveHakiHudY(client);
                    this.configManager.saveConfig(this.config);
                }
                client.method_1507(new HudLayoutScreen(this));
            }
        }
    }

    private boolean isEdgePressed(class_310 client, int keyCode) {
        boolean down = isDown(client, keyCode);
        boolean previous = this.hudKeyLatch.getOrDefault(keyCode, false);
        this.hudKeyLatch.put(keyCode, down);
        return down && !previous;
    }

    private static boolean isDown(class_310 client, int keyCode) {
        return class_3675.method_15987(client.method_22683().method_4490(), keyCode);
    }

    private void tryUpdateStatsFromLines(List<String> normalizedLines) {
        TooltipParsers.parseProfileStats(normalizedLines).ifPresent(this::applyProfileStatsIfArmed);
    }

    private void applyProfileStatsIfArmed(TooltipParsers.ProfileStatsData statsData) {
        boolean updated = this.profileStatsTracker.consumeProfileHoverSync(statsData);
        if (updated) {
            this.debugLogManager.logInternal(String.format(
                Locale.ROOT,
                "[STATS] synced via /profile hover: power=%.2f strength=%.2f speed=%.2f",
                statsData.power(),
                statsData.strength(),
                statsData.speed()
            ));
        }
    }

    private void onCommandSent(String command) {
        if (command == null || command.isBlank()) {
            return;
        }

        String normalized = command.trim();
        if (normalized.startsWith("/")) {
            normalized = normalized.substring(1);
        }
        int firstSpace = normalized.indexOf(' ');
        String root = firstSpace >= 0 ? normalized.substring(0, firstSpace) : normalized;
        if ("profile".equalsIgnoreCase(root)
            || "profil".equalsIgnoreCase(root)
            || "profilo".equalsIgnoreCase(root)) {
            this.profileStatsTracker.armProfileHoverSync();
            this.debugLogManager.logInternal("[STATS] /profile|/profil|/profilo detected: awaiting hover sync");
        }
    }

    private Optional<AuctionHighlighter.ActiveHighlight> getAuctionHighlightForSlot(class_1735 slot) {
        if (slot == null || !slot.method_7681()) {
            return Optional.empty();
        }

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) {
            return Optional.empty();
        }

        try {
            class_1799 stack = slot.method_7677();
            String itemKey = buildAuctionItemKey(stack);
            List<class_2561> tooltip = stack.method_7950(class_1792.class_9635.field_51353, client.field_1724, class_1836.field_41070);
            List<String> normalizedLines = TextUtil.normalizeLines(tooltip);
            Optional<AuctionHighlighter.ActiveHighlight> parsed =
                TooltipParsers.parseAuctionHighlight(normalizedLines, stack.method_7947()).flatMap(this.auctionHighlighter::createHighlight);
            if (parsed.isPresent()) {
                this.auctionHighlighter.update(itemKey, new TooltipParsers.AuctionParseResult(
                    parsed.get().sellingPrice(),
                    parsed.get().averagePrice(),
                    parsed.get().quantity(),
                    parsed.get().unitPrice(),
                    parsed.get().delta(),
                    Math.min(1.0D, Math.max(0.0D, Math.abs(parsed.get().delta()) / 0.5D))
                ));
                return parsed;
            }
            return this.auctionHighlighter.getCachedHighlight(itemKey);
        } catch (Throwable throwable) {
            this.debugLogManager.logInternal("Parser failure in ah-slot: "
                + throwable.getClass().getSimpleName() + " - " + throwable.getMessage());
            return this.auctionHighlighter.getCachedHighlight(buildAuctionItemKey(slot.method_7677()));
        }
    }

    private String buildAuctionItemKey(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return "";
        }
        return class_7923.field_41178.method_10221(stack.method_7909()) + "|"
            + TextUtil.normalize(stack.method_7964()) + "|"
            + stack.method_57353().hashCode() + "|"
            + stack.method_7947();
    }

    private void logAuctionHighlight(AuctionHighlighter.ActiveHighlight highlight, class_1735 slot, int screenX, int screenY) {
        int absX = screenX + slot.field_7873;
        int absY = screenY + slot.field_7872;
        String line = String.format(
            Locale.ROOT,
            "[AH] sell=%d avg=%d qty=%d unit=%d delta=%.3f color=0x%08X slot=(%d,%d) screen=(%d,%d) abs=(%d,%d)",
            highlight.sellingPrice(),
            highlight.averagePrice(),
            highlight.quantity(),
            highlight.unitPrice(),
            highlight.delta(),
            highlight.argbColor(),
            slot.field_7873,
            slot.field_7872,
            screenX,
            screenY,
            absX,
            absY
        );
        String previous = this.lastAuctionDebugLines.put(slot.field_7874, line);
        if (!line.equals(previous)) {
            this.debugLogManager.logInternal(line);
        }
    }

    private void savePersistentState(PersistentState state) {
        this.configManager.saveState(state);
    }

    private static boolean looksLikeBossTooltip(List<String> lines) {
        for (String line : lines) {
            String lower = line.toLowerCase(Locale.ROOT);
            if (lower.contains("respawn") || lower.contains("spawn") || lower.contains("apparition") || lower.contains("coord")) {
                return true;
            }
        }
        return false;
    }
}
