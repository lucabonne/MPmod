package net.minepiece.qol.ui;

import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_822;
import net.minecraft.class_9974;
import net.minepiece.qol.MinepieceQolClient;
import net.minepiece.qol.state.BossTracker;
import net.minepiece.qol.util.NumberParser;

public final class MinibossWaypointWorldRenderer {
    private static final float TIMER_TARGET_SCREEN_SCALE = 2.2F;
    private static final float TIMER_MIN_WORLD_SCALE = 0.03F;
    private static final int[] COLORS = {
        0xFFAA00,
        0x55CCFF,
        0xFF66AA,
        0x66FF66,
        0xFFFF66,
        0xAA88FF
    };

    private final MinepieceQolClient mod;

    public MinibossWaypointWorldRenderer(MinepieceQolClient mod) {
        this.mod = mod;
    }

    public void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(this::render);
    }

    private void render(WorldRenderContext context) {
        if (!this.mod.getConfig().allFeaturesVisible) {
            return;
        }
        if (context.matrixStack() == null || context.consumers() == null || context.camera() == null || context.world() == null) {
            return;
        }

        List<BossTracker.MinibossWaypoint> waypoints = this.mod.getBossTracker().getActiveMinibossWaypoints();
        if (waypoints.isEmpty()) {
            return;
        }

        class_4587 matrices = context.matrixStack();
        class_4597 consumers = context.consumers();
        class_243 cameraPos = context.camera().method_19326();
        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;
        float tickDelta = context.tickCounter() == null ? 0.0F : context.tickCounter().method_60637(true);
        long worldTime = context.world().method_8510();

        matrices.method_22903();
        matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

        int index = 0;
        for (BossTracker.MinibossWaypoint waypoint : waypoints) {
            int rgb = colorFor(waypoint.symbol(), index);
            float red = ((rgb >> 16) & 0xFF) / 255.0F;
            float green = ((rgb >> 8) & 0xFF) / 255.0F;
            float blue = (rgb & 0xFF) / 255.0F;

            double x = waypoint.x();
            double y = waypoint.y();
            double z = waypoint.z();

            class_4588 fill = consumers.getBuffer(class_1921.method_49047());
            class_9974.method_62300(matrices, fill, x, y, z, x + 1.0D, y + 1.0D, z + 1.0D, red, green, blue, 0.18F);

            class_4588 outline = consumers.getBuffer(class_1921.method_23594());
            class_9974.method_62295(matrices, outline, new class_238(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D), red, green, blue, 0.95F);

            matrices.method_22903();
            matrices.method_22904(x, y, z);
            class_822.method_3545(
                matrices,
                consumers,
                class_822.field_4338,
                tickDelta,
                1.0F,
                worldTime,
                0,
                256,
                rgb,
                0.18F,
                0.24F
            );
            matrices.method_22909();

            String timer = waypoint.remainingMs() <= 0L ? "READY" : NumberParser.formatTimer(waypoint.remainingMs());
            class_2561 timerText = class_2561.method_43470(timer);
            double dx = (x + 0.5D) - cameraPos.field_1352;
            double dy = (y + 1.02D) - cameraPos.field_1351;
            double dz = (z + 0.5D) - cameraPos.field_1350;
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double fovDeg = client.field_1690.method_41808().method_41753();
            double focalLength = (client.method_22683().method_4486() / 2.0D) / Math.tan(Math.toRadians(fovDeg) * 0.5D);
            // Keep label roughly constant on-screen size regardless of distance/FOV.
            float textScale = (float) (TIMER_TARGET_SCREEN_SCALE * distance / Math.max(1.0D, focalLength));
            if (textScale < TIMER_MIN_WORLD_SCALE) {
                textScale = TIMER_MIN_WORLD_SCALE;
            }
            matrices.method_22903();
            matrices.method_22904(x + 0.5D, y + 1.02D, z + 0.5D);
            matrices.method_22907(client.method_1561().method_24197());
            matrices.method_22905(textScale, -textScale, textScale);
            float textX = -textRenderer.method_27525(timerText) / 2.0F;
            int bgColor = (int) (client.field_1690.method_19343(0.25F) * 255.0F) << 24;
            int textColor = 0xFF000000 | rgb;
            textRenderer.method_27522(
                timerText,
                textX,
                0.0F,
                textColor,
                false,
                matrices.method_23760().method_23761(),
                consumers,
                class_327.class_6415.field_33994,
                bgColor,
                0x00F000F0
            );
            textRenderer.method_27522(
                timerText,
                textX,
                0.0F,
                textColor,
                false,
                matrices.method_23760().method_23761(),
                consumers,
                class_327.class_6415.field_33993,
                0x00000000,
                class_765.method_62228(0x00F000F0, 2)
            );
            matrices.method_22909();
            index++;
        }

        matrices.method_22909();
    }

    private static int colorFor(String symbol, int index) {
        int seed = (symbol == null || symbol.isBlank()) ? index : symbol.hashCode();
        int slot = Math.floorMod(seed, COLORS.length);
        return COLORS[slot];
    }
}
