package net.minepiece.qol.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_355.class)
public interface PlayerListHudAccessor {
    @Accessor("footer")
    class_2561 minepiece$getFooter();

    @Accessor("header")
    class_2561 minepiece$getHeader();
}
