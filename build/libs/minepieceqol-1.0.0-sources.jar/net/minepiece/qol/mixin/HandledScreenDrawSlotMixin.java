package net.minepiece.qol.mixin;

import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minepiece.qol.MinepieceQolClient;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class HandledScreenDrawSlotMixin extends class_437 {
    @Shadow
    protected int x;

    @Shadow
    protected int y;

    @Shadow
    @Nullable
    protected class_1735 focusedSlot;

    protected HandledScreenDrawSlotMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "drawSlot", at = @At("HEAD"))
    private void minepiece$drawAuctionTint(class_332 drawContext, class_1735 slot, CallbackInfo ci) {
        MinepieceQolClient mod = MinepieceQolClient.get();
        if (mod == null || slot == null || !slot.method_7681()) {
            return;
        }

        mod.renderAuctionTint(drawContext, slot.field_7873, slot.field_7872, this.x, this.y, slot);
    }

    @Inject(method = "drawMouseoverTooltip", at = @At("HEAD"))
    private void minepiece$captureHoveredBoss(class_332 drawContext, int mouseX, int mouseY, CallbackInfo ci) {
        MinepieceQolClient mod = MinepieceQolClient.get();
        if (mod == null || this.focusedSlot == null || !this.focusedSlot.method_7681()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }

        class_1799 stack = this.focusedSlot.method_7677();
        mod.captureBossFromTooltipLines(stack, this.method_25408(client, stack));
    }
}
