package net.minepiece.qol.state;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_7923;
import net.minepiece.qol.parse.TooltipParsers;
import net.minepiece.qol.util.TextUtil;

public final class BossGuiAutoScanner {
    private static final long SCAN_INTERVAL_MS = 500L;

    private final BossTracker bossTracker;
    private final DebugLogManager debugLogManager;
    private final Map<Integer, String> slotSignatures = new HashMap<>();

    private class_437 lastScreen;
    private long lastScanMs;

    public BossGuiAutoScanner(BossTracker bossTracker, DebugLogManager debugLogManager) {
        this.bossTracker = bossTracker;
        this.debugLogManager = debugLogManager;
    }

    public void tick(class_310 client) {
        if (client == null || client.field_1724 == null) {
            return;
        }

        class_437 currentScreen = client.field_1755;
        if (!(currentScreen instanceof class_465<?> handledScreen)) {
            resetScreenState();
            return;
        }

        if (this.bossTracker.getCurrentSpawnId().isBlank()) {
            return;
        }

        boolean screenChanged = currentScreen != this.lastScreen;
        if (screenChanged) {
            this.lastScreen = currentScreen;
            this.slotSignatures.clear();
            this.lastScanMs = 0L;
        }

        long now = System.currentTimeMillis();
        if (now - this.lastScanMs < SCAN_INTERVAL_MS) {
            return;
        }
        this.lastScanMs = now;

        int changedSlotsScanned = 0;
        String screenTitle = TextUtil.normalize(currentScreen.method_25440());

        for (int slotIndex = 0; slotIndex < handledScreen.method_17577().field_7761.size(); slotIndex++) {
            class_1735 slot = handledScreen.method_17577().field_7761.get(slotIndex);
            if (slot == null || !slot.method_7681()) {
                continue;
            }

            class_1799 stack = slot.method_7677();
            String signature = buildSignature(stack);
            String previous = this.slotSignatures.put(slotIndex, signature);
            if (signature.equals(previous)) {
                continue;
            }

            changedSlotsScanned++;
            List<class_2561> tooltip = stack.method_7950(class_1792.class_9635.field_51353, client.field_1724, class_1836.field_41070);
            List<String> normalizedLines = TextUtil.normalizeLines(tooltip);
            if (!containsBossKeywords(normalizedLines)) {
                log(String.format(Locale.ROOT, "[BOSS] skip slot=%d missing coords/timer keywords spawn=%s",
                    slotIndex,
                    this.bossTracker.getCurrentSpawnId()));
                continue;
            }

            Optional<TooltipParsers.BossTooltipData> parsed =
                TooltipParsers.parseBossTooltip(normalizedLines, TextUtil.normalize(stack.method_7964()));
            if (parsed.isEmpty()) {
                log(String.format(Locale.ROOT, "[BOSS] skip slot=%d incomplete coords/timer data spawn=%s",
                    slotIndex,
                    this.bossTracker.getCurrentSpawnId()));
                continue;
            }

            TooltipParsers.BossTooltipData data = parsed.get();
            this.bossTracker.captureParsedTooltip(data);
            log(String.format(
                Locale.ROOT,
                "[BOSS] parsed title=%s slot=%d name=%s coords=(%d,%d,%d) remaining=%ds cycle=%dm spawn=%s",
                quote(screenTitle),
                slotIndex,
                data.bossName(),
                data.x(),
                data.y(),
                data.z(),
                data.remainingSeconds(),
                data.cycleSeconds() / 60,
                this.bossTracker.getCurrentSpawnId()
            ));
        }

        if (screenChanged || changedSlotsScanned > 0) {
            log(String.format(Locale.ROOT, "[BOSS] scan title=%s changedSlots=%d totalSlots=%d spawn=%s",
                quote(screenTitle),
                changedSlotsScanned,
                handledScreen.method_17577().field_7761.size(),
                this.bossTracker.getCurrentSpawnId()));
        }
    }

    private void resetScreenState() {
        this.lastScreen = null;
        this.slotSignatures.clear();
        this.lastScanMs = 0L;
    }

    private void log(String message) {
        if (this.debugLogManager != null) {
            this.debugLogManager.logInternal(message);
        }
    }

    private static boolean containsBossKeywords(List<String> lines) {
        boolean hasCoords = false;
        boolean hasRespawn = false;
        for (String line : lines) {
            if (line.contains("Coordonn")) {
                hasCoords = true;
            }
            if (line.contains("Respawn")) {
                hasRespawn = true;
            }
            if (hasCoords && hasRespawn) {
                return true;
            }
        }
        return false;
    }

    private static String buildSignature(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return "";
        }
        return class_7923.field_41178.method_10221(stack.method_7909()) + "|" + stack.method_7947() + "|" + stack.method_57353().hashCode();
    }

    private static String quote(String value) {
        return "\"" + value.replace("\"", "'") + "\"";
    }
}
